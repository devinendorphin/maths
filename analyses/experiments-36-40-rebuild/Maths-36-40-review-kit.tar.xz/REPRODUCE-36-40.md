# Reproduce the rebuilt experiments 36–40

The new campaign is under `research36-rebuild/`. Its immutable policy, construction and event records, range audits, stage source snapshots, selection seal, timings and manifest are distinct from the three retained reports of the lost campaign.

Use Python 3.12 and the standard library. The GitHub runner's recorded version and platform are in `research36-rebuild/Environment.json`. Disable Python bytecode caches before importing the recovered kernels: extra cache files inside the unchanged 31–35 checkpoint would cause its file-set integrity check to fail.

To inspect or reproduce from GitHub:

```sh
git clone https://github.com/devinendorphin/maths.git
cd maths
export PYTHONDONTWRITEBYTECODE=1
python3 scripts/recover_campaign_31_35.py
```

That command verifies the imported baseline; it does not replay the old experiments.

For a fresh run, copy the source and handoff into a new output folder. Keep the saved campaign intact:

```sh
mkdir research36-reproduction
cp -a research36-rebuild/code research36-reproduction/code
cp research36-rebuild/Handoff.md research36-reproduction/Handoff.md
export MATHS_RESEARCH_ROOT="$PWD/research36-reproduction"
python3 "$MATHS_RESEARCH_ROOT/code/campaign.py" prepare
python3 "$MATHS_RESEARCH_ROOT/code/campaign.py" run --batch-seconds 900
```

Repeat the final bounded command until `Archive-verification.json` exists in the new folder. The controller reuses completed policy results and audit ranges. It refuses to replay a policy interrupted inside an unfinished action; that case requires exact continuation from its saved evidence. A frontier stopped by its frozen guard remains incomplete even if scalar fallback completes the observation window. No cap should be raised to relabel it complete.

The complete declared matrix contains 832 unique trajectories and 3,328 headline policy paths. The 1,152 timing workers and 216 selector-tuning workers are separate. Stage 39 seals selection before held-out execution; stage 40 carries the selection byte-identically. CPU and a timing-selected threshold can vary between environments. The original lost campaign cannot be reproduced or cross-validated proof by proof from its three aggregate reports.

The saved primary campaign can be downloaded as its tar.xz archive. If `Archive-verification.json` reports `archive_in_parts: true`, download the entire `research36-rebuild/archive-parts/` folder and run:

```sh
cd research36-rebuild/archive-parts
python3 reassemble.py
```

The script verifies every part and the assembled size and SHA256. The primary archive uses an explicit byte-identical reference to `campaigns/experiments-31-35/`; the checkpoint and its original reassembly parts remain in the repository.

`analyses/experiments-36-40-rebuild/` holds separate retrospective cohort/gate diagnostics and the supplemental later-window failure fixture. Its checked supplemental archive does not alter the primary campaign archive. These diagnostics never supplied policy or selector decisions. The separately counted fixture is outside the declared experiment, timing and tuning totals.

No worst-case efficiency or new arithmetic claim follows from these finite experiments.
