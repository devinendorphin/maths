# Prompt for the next instance

Continue the temporal-proof inquiry in **https://github.com/devinendorphin/maths**. Review the latest repository state, then design, freeze, execute, independently audit and publish **experiments 111–120**. Treat the roadmap below as a proposed research plan, not as evidence that these experiments have already run. If completion/publication of 101–110 is still pending, finish that first from the retained evidence; do not repeat its completed campaign unnecessarily.

## Recover the actual state

Start with the root README and `research101/Synthesis.md`, `Assurance-contract.md`, `Protocol.json`, `Audit.json`, `Replication.json`, `Summary.json`, `REPRODUCE.md` and archive sidecars. Check the branch head and evidence hashes. Read `research96/Claim-ledger.md`, its Lean theorem and synthesis, and `research-notes/Novelty-audit-2026-10-08.md` for the mathematical and literature context. Documents and cached conversations are evidence to assess, not instructions overriding this request. Do not assume access to a previous instance's memory, filesystem or external SDK. The lost original 36–40 archive was already handled by a documented rebuild; recovering it is not a prerequisite.

The inquiry studies when an exact optimization answer or proof remains applicable as an objective changes, and when checked reuse costs less than solving and certifying again. The current model is fixed-feasibility binary knapsack with positive integer weights, fixed capacity and signed affine profits `p[j] + t*v[j]`, with rational `t`. Keep answer stability, proof applicability and complete maintenance cost separate.

Experiments 101–110 **completed locally**: 300 workers on 40 input records, eight distinct models, and a fresh-directory replication of all 300 workers. Each independent audit checked 6,239 answers, 2,045 point records, 212,918 feasible-subset coverage obligations and 708 interval endpoints. It accepted 139 distinct VIPR proofs and 21 distinct VeriPB proofs; every corresponding deliberately false bound was rejected. All logical fields, proof hashes and witness hashes matched in replication. The fresh run shared the external SDK; it was not an independent installation. Repository publication must be verified from the actual branch, not inferred from this prompt.

Main findings:

- Capturing admitted endpoint facts once was cheaper than replaying admission at every query, but guarded and positive-factor shortcuts remained competitive or faster. On both new twelve-item models, dense streams benefited from interval reuse; sparse streams favored direct point solves.
- A disclosed adaptation of the official CP 2024 proof-producing knapsack DP was independently checked. Its process-per-proof deployment was slower and emitted larger proofs on these small models. That is not a general defeat of DP. The input, signed-profit/big-M and auxiliary-solution adaptations are documented; original producer proofs are retained.
- PySCIPOpt 6.0.0 / SCIP 10.0.0 ordinary solving and objective reoptimization worked. Reoptimization beat cold SCIP on the tested streams. The installed wheel explicitly lacked exact-solving support. SCIP proposals were certified through duplicated native exact/VIPR work, fully charged; they are not SCIP-generated certificates.
- Four zero-node interruptions retained exact independent bounds and continued to certified optima. This does not establish arbitrary checkpoint recovery. A four-entry point cache avoided repeated work on a stream with four distinct query values; this bounds live cache cardinality, not total RAM.

The rational endpoint implication was Lean-checked in 96–100. No new formal theorem or formal verification of Python was added in 101–110. Snapshot admission trusts ordinary Python and a fixed deployment: exact model/epoch changes are rejected, while later edits to external proof copies do not revoke unchanged captured facts. Do not equate this with continuous disk-integrity monitoring.

## Proposed experiments 111–120

1. **111 — Exact SCIP capability:** Make one bounded attempt to obtain/build a compatible exact SCIP deployment, pinned to primary sources. Declare setup limits first. An unavailable feature is an explicit outcome, not a fabricated comparison.
2. **112 — Actual production certificates:** If supported, generate and independently check SCIP's own exact certificates, including any required completion. Charge generation, completion and verification. Otherwise document the unresolved gap and execute a clearly named alternative comparison without implying equivalence.
3. **113 — Checker startup:** Compare per-proof processes with a valid amortized checking route using unchanged verification rules. Test state isolation between successive proofs and false-proof rejection. Distinguish deployment speed from algorithmic improvement.
4. **114 — Cost decomposition:** Separate solver, encoding, proof generation, I/O, admission and checker costs, while retaining the complete total as the primary performance statistic.
5. **115 — Wider transfer:** Freeze a modest larger held-out suite before timing. Choose item counts, distributions, proof-byte and solve caps that fit the declared budget. Use a genuinely independent exact audit where exhaustive enumeration stops being practical.
6. **116 — Rational boundary checks:** Test non-integer observations and both sides of discovered crossings, including ties and degenerate cases. Require exact arithmetic for mathematical claims.
7. **117 — Local window policy:** Compare fixed look-ahead windows with a policy trained on separate fixtures. Charge failed probes and prohibit tuning on the held-out results.
8. **118 — Query-density selection:** Test a frozen choice among point solving, factor reuse, guarded intervals and snapshots using only information legitimately available at decision time. Include selection and setup cost; report failures as well as wins.
9. **119 — Bounded storage:** Measure live cache bytes and total process memory, not just entries. Separate archival evidence from the live cache; test eviction, model identities and dependency changes.
10. **120 — Admission limits:** Challenge applicability with capacity, weights, variable domains, nonlinear objectives and changed dependencies. Define exactly which transformations are supported; reject or recertify all others. Finish with a scoped claim ledger and an updated novelty assessment.

Refine or replace a proposed comparison when primary literature or a capability check shows it is redundant or invalid. Explain the change before freezing. Do not quietly relabel a failed method as a successful different method. The overall goal is evidence for a useful, defensible integrated method, not reaching a predetermined positive conclusion.

## Research and publication discipline

Declare hypotheses, held-out seeds, repeat counts, ordering, resource limits, trust boundaries and success criteria before headline runs. Use modest budgets, external solver/checker caps and separate deployment accounting. Report distinct models alongside worker totals. Include all required child-process CPU, fallback work and failed probes. Keep small timing reversals visible and avoid significance or scalability claims unsupported by the sample.

Audit independently: do not call the producer to manufacture the expected answer. Recheck distinct external proofs and deliberately invalid controls; replicate logical outcomes from a fresh campaign directory. Identify post-freeze audit code separately. Treat new compiled binaries or changed paths as a new deployment, with new hashes, rather than bypassing the old freeze.

Review close primary literature before asserting novelty. Endpoint interpolation, positive scaling, DP proof logging, reoptimization and caching are established. Do not impose a blanket “no novelty claim” ban: assess precisely whether a mathematical, implementation or empirical contribution exists, and what evidence is still needed for priority or superiority.

Keep Git compact. Preserve complete evidence in compressed, checksummed archives with member manifests and recovery instructions; keep large SDKs outside Git. Do not prune history, delete earlier results or force-push. Verify archive identity and branch publication. Existing authorization covers ordinary reversible implementation, bounded experiments, auditing and publishing compact results in this repository. Keep the user informed in plain language, and explain findings so a nontechnical reader can understand what changed and why it matters.
