from setuptools import setup,Extension
import pybind11
setup(name='veripb',version='2.3.0',packages=['veripb','veripb.optimized'],ext_modules=[Extension('veripb.optimized.pybindings',sources=['veripb/optimized/'+s for s in ['pybindings.cpp','constraints.cpp','parsing.cpp','gzstream.cpp']],include_dirs=[pybind11.get_include()],extra_compile_args=['--std=c++17','-DPY_BINDINGS','-O3','-DNDEBUG'],libraries=['gmp','gmpxx','z'],language='c++')])
